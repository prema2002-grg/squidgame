import { Code2, Globe, Database, Cloud, GitBranch, Wrench, Download } from "lucide-react";
import { ScrollReveal, ScaleIn } from "../components/ScrollReveal";
import { motion } from "motion/react";

export function Skills() {
  const skillCategories = [
    {
      title: "Programming Languages",
      icon: <Code2 size={32} />,
      color: "primary",
      skills: ["JavaScript", "TypeScript", "Python", "Java", "C#", "SQL"],
    },
    {
      title: "Web Development",
      icon: <Globe size={32} />,
      color: "accent",
      skills: ["React", "Node.js", "HTML/CSS", "REST APIs", "GraphQL", "Tailwind CSS"],
    },
    {
      title: "Databases",
      icon: <Database size={32} />,
      color: "teal",
      skills: ["PostgreSQL", "MongoDB", "MySQL", "Redis", "Supabase"],
    },
    {
      title: "Cloud & DevOps",
      icon: <Cloud size={32} />,
      color: "blue",
      skills: ["AWS", "Docker", "CI/CD", "Linux", "Azure", "Kubernetes"],
    },
    {
      title: "Version Control",
      icon: <GitBranch size={32} />,
      color: "purple",
      skills: ["Git", "GitHub", "GitLab", "Branching", "Pull Requests"],
    },
    {
      title: "Tools & Software",
      icon: <Wrench size={32} />,
      color: "orange",
      skills: ["VS Code", "IntelliJ", "Postman", "Figma", "Jira", "Slack"],
    },
  ];

  const getColorClasses = (color: string) => {
    const colorMap: Record<string, { bg: string; text: string; bullet: string }> = {
      primary: {
        bg: "from-primary-400 to-primary-600",
        text: "text-primary-600",
        bullet: "bg-primary-400",
      },
      accent: {
        bg: "from-accent-400 to-accent-600",
        text: "text-accent-600",
        bullet: "bg-accent-400",
      },
      teal: {
        bg: "from-teal-400 to-teal-600",
        text: "text-teal-600",
        bullet: "bg-teal-400",
      },
      blue: {
        bg: "from-blue-400 to-blue-600",
        text: "text-blue-600",
        bullet: "bg-blue-400",
      },
      purple: {
        bg: "from-purple-400 to-purple-600",
        text: "text-purple-600",
        bullet: "bg-purple-400",
      },
      orange: {
        bg: "from-orange-400 to-orange-600",
        text: "text-orange-600",
        bullet: "bg-orange-400",
      },
    };
    return colorMap[color] || colorMap.primary;
  };

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="py-20 px-4 bg-gradient-to-br from-primary-100 to-accent-100">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <h1 className="text-primary-600 mb-6">Skills & Resume</h1>
            <p className="text-gray-700 text-lg mb-8">
              A comprehensive overview of my technical expertise and professional qualifications
            </p>
            <button className="inline-flex items-center gap-2 bg-primary-600 text-white px-8 py-3 rounded-lg hover:bg-primary-700 transition-all duration-300 hover:shadow-lg hover:scale-105">
              <Download size={20} />
              Download Resume
            </button>
          </motion.div>
        </div>
      </section>

      {/* Skills Grid */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {skillCategories.map((category, index) => {
              const colors = getColorClasses(category.color);
              return (
                <ScaleIn key={index} delay={index * 0.05}>
                  <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
                    <div
                      className={`w-16 h-16 bg-gradient-to-br ${colors.bg} rounded-xl flex items-center justify-center mb-6 text-white`}
                    >
                      {category.icon}
                    </div>
                    <h3 className={`${colors.text} mb-6`}>{category.title}</h3>
                    <ul className="space-y-3">
                      {category.skills.map((skill, idx) => (
                        <motion.li
                          key={idx}
                          initial={{ opacity: 0, x: -20 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          viewport={{ once: true }}
                          transition={{ delay: idx * 0.03, duration: 0.3 }}
                          className="text-gray-700 flex items-start gap-3"
                        >
                          <span
                            className={`w-2 h-2 ${colors.bullet} rounded-full mt-2 flex-shrink-0`}
                          ></span>
                          <span>{skill}</span>
                        </motion.li>
                      ))}
                    </ul>
                  </div>
                </ScaleIn>
              );
            })}
          </div>
        </div>
      </section>

      {/* Additional Info Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-white to-primary-50">
        <div className="max-w-4xl mx-auto">
          <ScrollReveal>
            <div className="bg-white rounded-xl p-8 md:p-12 shadow-lg hover:shadow-2xl transition-shadow duration-300">
              <h2 className="text-primary-600 mb-6 text-center">Continuous Learning</h2>
              <p className="text-gray-700 text-center text-lg leading-relaxed">
                I'm constantly expanding my skill set through hands-on projects, online courses, 
                and staying up-to-date with the latest technologies in cloud computing and IT infrastructure. 
                Every project is an opportunity to learn something new and improve my technical expertise.
              </p>
            </div>
          </ScrollReveal>
        </div>
      </section>
    </div>
  );
}
