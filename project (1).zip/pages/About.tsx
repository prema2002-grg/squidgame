import { Palette, Coffee, ChefHat, Youtube, Camera, PuzzleIcon } from "lucide-react";
import { ScrollReveal, ScaleIn } from "../components/ScrollReveal";
import { motion } from "motion/react";

export function About() {
  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="py-20 px-4 bg-gradient-to-br from-primary-100 to-accent-100">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <h1 className="text-primary-600 mb-6">About Prema Gurung</h1>
            <h3 className="text-gray-800 mb-4">Professional Journey</h3>
            <p className="text-gray-700 text-lg leading-relaxed">
              Hi, my name is Prema Gurung, and I am a student in Cloud Computing at George Brown College. I am passionate about technology, problem-solving, and building practical solutions that make systems more efficient and user-friendly.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Professional Experience */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <ScrollReveal>
            <div className="bg-white rounded-xl p-8 md:p-12 shadow-lg hover:shadow-2xl transition-shadow duration-300">
              <h2 className="text-primary-600 mb-6">Experience & Goals</h2>
              <div className="space-y-6 text-gray-700 text-lg leading-relaxed">
                <p>
                  Throughout my academic journey, I have gained hands-on experience with tools such as AWS, networking fundamentals, cloud computing, Linux, Windows Server administration, system design, and troubleshooting. I enjoy learning new technologies and applying them to real-world projects.
                </p>
                <p>
                  My goal is to build a career where I can contribute to designing secure and scalable systems while continuing to grow my technical and professional skills.
                </p>
                <p>
                  With over a year of IT support experience and multiple cloud projects under my belt, I'm constantly expanding my portfolio and taking on new challenges that push my boundaries.
                </p>
              </div>
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-20 px-4 bg-gradient-to-b from-white to-primary-50">
        <div className="max-w-6xl mx-auto">
          <ScrollReveal>
            <h2 className="text-center text-primary-600 mb-12">Core Values</h2>
          </ScrollReveal>
          <div className="grid md:grid-cols-3 gap-8">
            <ScaleIn delay={0.1}>
              <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-primary-400 to-accent-500 rounded-xl flex items-center justify-center mb-6 text-white mx-auto">
                  <Coffee size={32} />
                </div>
                <h3 className="text-primary-600 mb-4">Problem Solving</h3>
                <p className="text-gray-700">
                  Approaching challenges with creativity and analytical thinking to find efficient solutions
                </p>
              </div>
            </ScaleIn>

            <ScaleIn delay={0.2}>
              <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-primary-400 to-accent-500 rounded-xl flex items-center justify-center mb-6 text-white mx-auto">
                  <Palette size={32} />
                </div>
                <h3 className="text-accent-600 mb-4">Continuous Learning</h3>
                <p className="text-gray-700">
                  Always eager to learn new technologies and improve existing skills through hands-on practice
                </p>
              </div>
            </ScaleIn>

            <ScaleIn delay={0.3}>
              <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-primary-400 to-accent-500 rounded-xl flex items-center justify-center mb-6 text-white mx-auto">
                  <Camera size={32} />
                </div>
                <h3 className="text-teal-600 mb-4">User-Focused</h3>
                <p className="text-gray-700">
                  Building practical solutions that are efficient, user-friendly, and make a real difference
                </p>
              </div>
            </ScaleIn>
          </div>
        </div>
      </section>
    </div>
  );
}