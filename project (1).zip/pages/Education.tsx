import {
  GraduationCap,
  Award,
  FileText,
  Trophy,
  Heart,
} from "lucide-react";
import {
  ScrollReveal,
  ScaleIn,
  SlideInLeft,
  SlideInRight,
} from "../components/ScrollReveal";
import { motion } from "motion/react";

export function Education() {
  const education = [
    {
      degree: "Bachelor of Science in Computer Science",
      institution: "Herald College",
      period: "2020 - 2023",
      gpa: "GPA: 3.2/4.0",
    },
    {
      degree: "Post Graduate Cloud Computing",
      institution: "George Brown College",
      period: "2024-2025",
      gpa: "GPA: To be decide",
    },
  ];

  const certifications = [
    {
      title: "AWS Certified Cloud Practitioner",
      issuer: "Amazon Web Services",
      year: "2025",
    },
  ];

  const awards = [
    {
      title: "Best Project Award",
      description:
        "University Management System - Recognized for innovative solution and implementation",
      year: "2024",
      icon: <Trophy size={24} />,
    },
    {
      title: "Best Discipline Captain",
      description:
        "Basketball Team - Awarded for leadership and sportsmanship",
      year: "2023",
      icon: <Award size={24} />,
    },
    {
      title: "Top 5 - Dance Competition",
      description:
        "Intra Group Dance Competition - Recognized for outstanding performance",
      year: "2023",
      icon: <Award size={24} />,
    },
    {
      title: "Community Service",
      description:
        "Nepal Scout Volunteer - Participated in environmental cleaning initiatives",
      year: "2022-2023",
      icon: <Heart size={24} />,
    },
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="py-20 px-4 bg-gradient-to-br from-primary-100 to-accent-100">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <h1 className="text-primary-600 mb-6">
              Education & Achievements
            </h1>
          </motion.div>
        </div>
      </section>

      {/* Education Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <ScrollReveal>
            <h2 className="text-primary-600 mb-12">
              Education
            </h2>
          </ScrollReveal>
          <div className="space-y-6">
            {education.map((edu, index) => (
              <SlideInLeft key={index} delay={index * 0.1}>
                <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-primary-400 to-primary-600 rounded-lg flex items-center justify-center text-white flex-shrink-0">
                      <GraduationCap size={24} />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-primary-600 mb-2">
                        {edu.degree}
                      </h3>
                      <p className="text-gray-700 mb-1">
                        {edu.institution}
                      </p>
                      <div className="flex flex-wrap gap-4 text-gray-600">
                        <span>{edu.period}</span>
                        <span>•</span>
                        <span>{edu.gpa}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </SlideInLeft>
            ))}
          </div>
        </div>
      </section>

      {/* Certifications Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-white to-primary-50">
        <div className="max-w-6xl mx-auto">
          <ScrollReveal>
            <h2 className="text-primary-600 mb-12">
              Certifications
            </h2>
          </ScrollReveal>
          <div className="grid md:grid-cols-2 gap-6">
            {certifications.map((cert, index) => (
              <ScaleIn key={index} delay={index * 0.1}>
                <div className="bg-white rounded-xl p-6 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 bg-gradient-to-br from-accent-400 to-accent-600 rounded-lg flex items-center justify-center text-white flex-shrink-0">
                      <Award size={20} />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-accent-600 mb-1">
                        {cert.title}
                      </h4>
                      <p className="text-gray-600 text-sm mb-1">
                        {cert.issuer}
                      </p>
                      <p className="text-gray-500 text-sm">
                        {cert.year}
                      </p>
                    </div>
                  </div>
                </div>
              </ScaleIn>
            ))}
          </div>
        </div>
      </section>

      {/* Awards Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <ScrollReveal>
            <h2 className="text-primary-600 mb-12">
              Awards & Recognition
            </h2>
          </ScrollReveal>
          <div className="grid md:grid-cols-2 gap-6">
            {awards.map((award, index) => (
              <ScaleIn key={index} delay={index * 0.1}>
                <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
                  <div className="flex items-start gap-4 mb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-lg flex items-center justify-center text-white flex-shrink-0">
                      {award.icon}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-gray-900 mb-2">
                        {award.title}
                      </h3>
                      <p className="text-gray-600 text-sm mb-2">
                        {award.description}
                      </p>
                      <p className="text-gray-500 text-sm">
                        {award.year}
                      </p>
                    </div>
                  </div>
                </div>
              </ScaleIn>
            ))}
          </div>
        </div>
      </section>

      {/* Transcripts Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-white to-primary-50">
        <div className="max-w-4xl mx-auto">
          <ScrollReveal>
            <div className="bg-white rounded-xl p-8 md:p-12 shadow-lg hover:shadow-2xl transition-shadow duration-300 text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-primary-400 to-primary-600 rounded-xl flex items-center justify-center text-white mx-auto mb-6">
                <FileText size={32} />
              </div>
              <h2 className="text-primary-600 mb-4">
                Academic Transcripts
              </h2>
              <p className="text-gray-700 mb-8">
                Official and unofficial transcripts available
              </p>
              <button className="bg-primary-600 text-white px-8 py-3 rounded-lg hover:bg-primary-700 transition-all duration-300 hover:shadow-lg hover:scale-105">
                Add Transcript
              </button>
            </div>
          </ScrollReveal>
        </div>
      </section>
    </div>
  );
}