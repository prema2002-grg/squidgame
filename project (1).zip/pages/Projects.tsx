import { Cloud, Server, Network } from "lucide-react";
import { ScrollReveal, ScaleIn } from "../components/ScrollReveal";
import { motion } from "motion/react";

export function Projects() {
  const projectSections = [
    {
      title: "AWS Projects",
      icon: <Cloud size={32} />,
      color: "primary",
      projects: [
        "EC2 On-Demand vs Reserved",
        "Creating & configuring Security Groups",
        "Load Balancers + Target Group troubleshooting",
        "Auto Scaling Groups configuration",
        "S3 static website hosting",
        "IAM users, roles & policies",
        "VPC networking setup",
        "Checking unhealthy targets",
      ],
    },
    {
      title: "Windows Server Projects",
      icon: <Server size={32} />,
      color: "accent",
      projects: [
        "Domain Controller setup (AD DS)",
        "DNS forwarders & zones",
        "DHCP scope config",
        "iSCSI target setup",
        "Hyper-V Replica configuration",
        "WSUS installation & maintenance",
        "Windows Server Backup",
        "BitLocker & Defender security configs",
      ],
    },
    {
      title: "Networking Labs",
      icon: <Network size={32} />,
      color: "teal",
      projects: [
        "DHCP on wireless routers",
        "Static & dynamic IP testing",
        "Connectivity troubleshooting",
        "Basic VLAN setups",
        "Packet Tracer topology builds",
      ],
    },
  ];

  const getColorClasses = (color: string) => {
    switch (color) {
      case "primary":
        return {
          bg: "from-primary-400 to-primary-600",
          text: "text-primary-600",
          cardBg: "bg-primary-50",
          hover: "hover:bg-primary-100",
        };
      case "accent":
        return {
          bg: "from-accent-400 to-accent-600",
          text: "text-accent-600",
          cardBg: "bg-accent-50",
          hover: "hover:bg-accent-100",
        };
      case "teal":
        return {
          bg: "from-teal-400 to-teal-600",
          text: "text-teal-600",
          cardBg: "bg-teal-50",
          hover: "hover:bg-teal-100",
        };
      default:
        return {
          bg: "from-gray-400 to-gray-600",
          text: "text-gray-600",
          cardBg: "bg-gray-50",
          hover: "hover:bg-gray-100",
        };
    }
  };

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="py-20 px-4 bg-gradient-to-br from-primary-100 to-accent-100">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <h1 className="text-primary-600 mb-6">Projects</h1>
            <p className="text-gray-700 text-lg">
              A showcase of my hands-on technical projects across cloud computing, server administration, 
              and networking.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Projects Sections */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto space-y-16">
          {projectSections.map((section, index) => {
            const colors = getColorClasses(section.color);
            return (
              <div key={index}>
                <ScrollReveal delay={index * 0.1}>
                  <div className="flex items-center gap-4 mb-8">
                    <div
                      className={`w-16 h-16 bg-gradient-to-br ${colors.bg} rounded-xl flex items-center justify-center text-white flex-shrink-0`}
                    >
                      {section.icon}
                    </div>
                    <h2 className={colors.text}>{section.title}</h2>
                  </div>
                </ScrollReveal>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {section.projects.map((project, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: idx * 0.05, duration: 0.4 }}
                      className={`${colors.cardBg} ${colors.hover} rounded-lg p-6 transition-all duration-300 hover:shadow-lg hover:-translate-y-1`}
                    >
                      <div className="flex items-start gap-3">
                        <span
                          className={`w-2 h-2 ${colors.bg.includes('primary') ? 'bg-primary-400' : colors.bg.includes('accent') ? 'bg-accent-400' : 'bg-teal-400'} rounded-full mt-2 flex-shrink-0`}
                        ></span>
                        <p className="text-gray-700">{project}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-white to-primary-50">
        <div className="max-w-4xl mx-auto text-center">
          <ScrollReveal>
            <div className="bg-white rounded-xl p-8 md:p-12 shadow-lg hover:shadow-2xl transition-shadow duration-300">
              <h2 className="text-primary-600 mb-6">Want to Know More?</h2>
              <p className="text-gray-700 text-lg leading-relaxed mb-8">
                Each project represents hands-on learning and practical application of technical concepts. 
                I'm always working on new projects and expanding my portfolio.
              </p>
              <a
                href="/contact"
                className="inline-block bg-primary-600 text-white px-8 py-3 rounded-lg hover:bg-primary-700 transition-all duration-300 hover:shadow-lg hover:scale-105"
              >
                Get in Touch
              </a>
            </div>
          </ScrollReveal>
        </div>
      </section>
    </div>
  );
}