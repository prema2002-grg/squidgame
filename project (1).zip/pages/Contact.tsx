import { Mail, Linkedin, Github, Send } from "lucide-react";
import { useState } from "react";
import { ScrollReveal, SlideInLeft, SlideInRight } from "../components/ScrollReveal";
import { motion } from "motion/react";

export function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real application, you would send this data to a backend
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setFormData({ name: "", email: "", subject: "", message: "" });
    }, 3000);
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="py-20 px-4 bg-gradient-to-br from-primary-100 to-accent-100">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <h1 className="text-primary-600 mb-6">Get In Touch</h1>
            <p className="text-gray-700 text-lg">
              I'm always open to discussing new opportunities, collaborations, or just connecting
            </p>
          </motion.div>
        </div>
      </section>

      {/* Contact Info & Form Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Information */}
            <SlideInLeft>
              <div>
                <h2 className="text-primary-600 mb-8">Contact Information</h2>
                <div className="space-y-6">
                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    transition={{ duration: 0.2 }}
                    className="flex items-start gap-4"
                  >
                    <div className="w-12 h-12 bg-gradient-to-br from-primary-400 to-primary-600 rounded-lg flex items-center justify-center text-white flex-shrink-0">
                      <Mail size={24} />
                    </div>
                    <div>
                      <h3 className="text-gray-900 mb-2">Email</h3>
                      <p className="text-gray-600">your.email@example.com</p>
                    </div>
                  </motion.div>

                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    transition={{ duration: 0.2 }}
                    className="flex items-start gap-4"
                  >
                    <div className="w-12 h-12 bg-gradient-to-br from-accent-400 to-accent-600 rounded-lg flex items-center justify-center text-white flex-shrink-0">
                      <Linkedin size={24} />
                    </div>
                    <div>
                      <h3 className="text-gray-900 mb-2">Phone</h3>
                      <p className="text-gray-600">+1 (234) 567-890</p>
                    </div>
                  </motion.div>

                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    transition={{ duration: 0.2 }}
                    className="flex items-start gap-4"
                  >
                    <div className="w-12 h-12 bg-gradient-to-br from-teal-400 to-teal-600 rounded-lg flex items-center justify-center text-white flex-shrink-0">
                      <Github size={24} />
                    </div>
                    <div>
                      <h3 className="text-gray-900 mb-2">Location</h3>
                      <p className="text-gray-600">City, State, Country</p>
                    </div>
                  </motion.div>
                </div>

                <div className="mt-12">
                  <h3 className="text-primary-600 mb-6">Connect With Me</h3>
                  <div className="space-y-4">
                    <motion.a
                      whileHover={{ scale: 1.02 }}
                      href="https://linkedin.com/in/yourprofile"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-3 p-4 bg-gradient-to-br from-primary-50 to-accent-50 rounded-lg hover:shadow-lg transition-all duration-300"
                    >
                      <Linkedin size={24} className="text-primary-600" />
                      <div>
                        <p className="text-gray-900">LinkedIn</p>
                        <p className="text-gray-600 text-sm">linkedin.com/in/yourprofile</p>
                      </div>
                    </motion.a>
                    <motion.a
                      whileHover={{ scale: 1.02 }}
                      href="https://github.com/yourusername"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-3 p-4 bg-gradient-to-br from-primary-50 to-accent-50 rounded-lg hover:shadow-lg transition-all duration-300"
                    >
                      <Github size={24} className="text-gray-900" />
                      <div>
                        <p className="text-gray-900">GitHub</p>
                        <p className="text-gray-600 text-sm">github.com/yourusername</p>
                      </div>
                    </motion.a>
                  </div>
                </div>
              </div>
            </SlideInLeft>

            {/* Contact Form */}
            <SlideInRight>
              <div>
                <div className="bg-white rounded-xl shadow-lg p-8 hover:shadow-2xl transition-shadow duration-300">
                  <h2 className="text-primary-600 mb-6">Send Me an Email</h2>
                  {submitted ? (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="bg-green-50 border border-green-200 rounded-lg p-6 text-center"
                    >
                      <p className="text-green-700">
                        Thank you for your message! I'll get back to you soon.
                      </p>
                    </motion.div>
                  ) : (
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div>
                        <label htmlFor="name" className="block text-gray-700 mb-2">
                          Name
                        </label>
                        <input
                          type="text"
                          id="name"
                          name="name"
                          value={formData.name}
                          onChange={handleChange}
                          required
                          className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all duration-300"
                          placeholder="Your name"
                        />
                      </div>

                      <div>
                        <label htmlFor="email" className="block text-gray-700 mb-2">
                          Email
                        </label>
                        <input
                          type="email"
                          id="email"
                          name="email"
                          value={formData.email}
                          onChange={handleChange}
                          required
                          className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all duration-300"
                          placeholder="your.email@example.com"
                        />
                      </div>

                      <div>
                        <label htmlFor="subject" className="block text-gray-700 mb-2">
                          Subject
                        </label>
                        <input
                          type="text"
                          id="subject"
                          name="subject"
                          value={formData.subject}
                          onChange={handleChange}
                          required
                          className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all duration-300"
                          placeholder="What's this about?"
                        />
                      </div>

                      <div>
                        <label htmlFor="message" className="block text-gray-700 mb-2">
                          Message
                        </label>
                        <textarea
                          id="message"
                          name="message"
                          value={formData.message}
                          onChange={handleChange}
                          required
                          rows={5}
                          className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all duration-300 resize-none"
                          placeholder="Your message here..."
                        />
                      </div>

                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        type="submit"
                        className="w-full bg-primary-600 text-white py-3 rounded-lg hover:bg-primary-700 transition-all duration-300 flex items-center justify-center gap-2 hover:shadow-lg"
                      >
                        Send Message <Send size={20} />
                      </motion.button>
                    </form>
                  )}
                </div>
              </div>
            </SlideInRight>
          </div>
        </div>
      </section>
    </div>
  );
}