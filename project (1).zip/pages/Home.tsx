import { Link } from "react-router-dom";
import { ArrowRight, Cloud, Server, Code } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { motion } from "motion/react";
import { ScrollReveal, ScaleIn } from "../components/ScrollReveal";

export function Home() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-[70vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary-400 via-primary-500 to-accent-500">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1646038572815-43fe759e459b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMHB1cnBsZSUyMGdyYWRpZW50fGVufDF8fHx8MTc2MzkwMTc5NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Abstract gradient background"
            className="w-full h-full object-cover opacity-30"
          />
        </div>
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto text-white">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <h1 className="mb-6">Prema Gurung</h1>
          </motion.div>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
            className="text-xl opacity-90 max-w-2xl mx-auto"
          >
            Cloud Computing Student | IT Support Specialist | Tech Enthusiast
          </motion.p>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3, ease: "easeOut" }}
            className="text-lg opacity-80 max-w-2xl mx-auto mt-4"
          >
            Passionate about technology, problem-solving, and building practical solutions that make systems more efficient and user-friendly.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4, ease: "easeOut" }}
            className="flex flex-wrap gap-4 justify-center mt-8"
          >
            <Link
              to="/projects"
              className="bg-white text-primary-600 px-8 py-3 rounded-lg hover:bg-primary-50 transition-all duration-300 hover:shadow-lg hover:scale-105 inline-flex items-center gap-2"
            >
              View My Work <ArrowRight size={20} />
            </Link>
            <Link
              to="/contact"
              className="bg-primary-600/20 backdrop-blur-sm text-white px-8 py-3 rounded-lg hover:bg-primary-600/30 transition-all duration-300 border border-white/30 hover:scale-105"
            >
              Get In Touch
            </Link>
          </motion.div>
        </div>
      </section>

      {/* About Me Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <ScrollReveal>
            <div className="bg-white rounded-2xl p-8 md:p-12 shadow-lg hover:shadow-2xl transition-shadow duration-300">
              <h2 className="text-primary-600 mb-6">About Me</h2>
              <h3 className="text-gray-800 mb-4">Professional Summary</h3>
              <p className="text-gray-700 text-lg leading-relaxed mb-4">
                Hi, my name is Prema Gurung, and I am a student in Cloud Computing at George Brown College. I am passionate about technology, problem-solving, and building practical solutions that make systems more efficient and user-friendly.
              </p>
              <p className="text-gray-700 text-lg leading-relaxed mb-4">
                Throughout my academic journey, I have gained hands-on experience with tools such as AWS, networking fundamentals, cloud computing, Linux, Windows Server administration, system design, and troubleshooting. I enjoy learning new technologies and applying them to real-world projects.
              </p>
              <p className="text-gray-700 text-lg leading-relaxed">
                My goal is to build a career where I can contribute to designing secure and scalable systems while continuing to grow my technical and professional skills.
              </p>
              <Link
                to="/about"
                className="inline-flex items-center gap-2 mt-6 text-primary-600 hover:text-primary-700 transition-all duration-300 hover:gap-3"
              >
                Learn more about me <ArrowRight size={20} />
              </Link>
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-white to-primary-50">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8">
            <ScaleIn delay={0.1}>
              <div className="bg-white rounded-xl p-8 shadow-lg text-center hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
                <div className="text-4xl text-primary-600 mb-2">1+</div>
                <p className="text-gray-700">Year IT Support</p>
              </div>
            </ScaleIn>
            <ScaleIn delay={0.2}>
              <div className="bg-white rounded-xl p-8 shadow-lg text-center hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
                <div className="text-4xl text-accent-600 mb-2">Multiple</div>
                <p className="text-gray-700">Cloud Projects</p>
              </div>
            </ScaleIn>
            <ScaleIn delay={0.3}>
              <div className="bg-white rounded-xl p-8 shadow-lg text-center hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
                <div className="text-4xl text-teal-600 mb-2">Growing</div>
                <p className="text-gray-700">Skill Portfolio</p>
              </div>
            </ScaleIn>
          </div>
        </div>
      </section>

      {/* Featured Projects Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-primary-50 to-white">
        <div className="max-w-6xl mx-auto">
          <ScrollReveal>
            <h2 className="text-center text-primary-600 mb-12">Work Samples</h2>
            <p className="text-center text-gray-700 text-lg mb-12">A collection of my recent projects demonstrating technical skills and creativity</p>
          </ScrollReveal>
          <div className="grid md:grid-cols-3 gap-8">
            {/* Card 1 */}
            <ScaleIn delay={0.1}>
              <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
                <div className="w-12 h-12 bg-gradient-to-br from-red-400 to-red-600 rounded-lg flex items-center justify-center mb-6">
                  <Server className="text-white" size={24} />
                </div>
                <h3 className="text-red-600 mb-4">Blood Bank Management System</h3>
                <p className="text-gray-700 mb-6">
                  Comprehensive blood bank management system for tracking donors, blood inventory, and requests. Features include donor registration, blood type management, and emergency alerts.
                </p>
                <div className="flex flex-wrap gap-2 mb-6">
                  <span className="px-3 py-1 bg-red-50 text-red-600 rounded-full text-sm">Database Management</span>
                  <span className="px-3 py-1 bg-red-50 text-red-600 rounded-full text-sm">Healthcare IT</span>
                  <span className="px-3 py-1 bg-red-50 text-red-600 rounded-full text-sm">System Design</span>
                </div>
              </div>
            </ScaleIn>

            {/* Card 2 */}
            <ScaleIn delay={0.2}>
              <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-600 rounded-lg flex items-center justify-center mb-6">
                  <Code className="text-white" size={24} />
                </div>
                <h3 className="text-blue-600 mb-4">College Management System</h3>
                <p className="text-gray-700 mb-6">
                  Full-featured college management system for student enrollment, course management, attendance tracking, and grade management. Streamlines administrative processes.
                </p>
                <div className="flex flex-wrap gap-2 mb-6">
                  <span className="px-3 py-1 bg-blue-50 text-blue-600 rounded-full text-sm">Education Tech</span>
                  <span className="px-3 py-1 bg-blue-50 text-blue-600 rounded-full text-sm">Database</span>
                  <span className="px-3 py-1 bg-blue-50 text-blue-600 rounded-full text-sm">User Management</span>
                </div>
              </div>
            </ScaleIn>

            {/* Card 3 */}
            <ScaleIn delay={0.3}>
              <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-400 to-purple-600 rounded-lg flex items-center justify-center mb-6">
                  <Code className="text-white" size={24} />
                </div>
                <h3 className="text-purple-600 mb-4">Unity Game Project</h3>
                <p className="text-gray-700 mb-6">
                  Interactive game developed using Unity engine featuring engaging gameplay mechanics, 3D graphics, and immersive user experience.
                </p>
                <div className="flex flex-wrap gap-2 mb-6">
                  <span className="px-3 py-1 bg-purple-50 text-purple-600 rounded-full text-sm">Unity</span>
                  <span className="px-3 py-1 bg-purple-50 text-purple-600 rounded-full text-sm">C#</span>
                  <span className="px-3 py-1 bg-purple-50 text-purple-600 rounded-full text-sm">Game Development</span>
                </div>
              </div>
            </ScaleIn>
          </div>
        </div>
      </section>
    </div>
  );
}